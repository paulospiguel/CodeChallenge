import React from "react";
import styled from "styled-components";

export const Container = styled.div``;

export default function ButtonSimulator() {
  return <button>Simular</button>;
}
